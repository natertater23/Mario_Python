from pygame import *
from pygame.sprite import Sprite
import Settings

class QuestionBrick(Sprite):
    def __init__(self, xpos, ypos, contains = 'Coin'):
        Sprite.__init__(self)
        self.index = 78
        self.image = Settings.QUESTION_IMAGES['78']
        self.rect = self.image.get_rect(topleft=(xpos,ypos))
        self.contents = contains
        self.gotHit = False
        self.startingY = self.rect.bottom
        self.gameTimer = time.get_ticks()
        '''  UNCOMMENT WHEN WE HAVE SOUNDS
        self.soundPlayed = False
        self.coinSound = mixer.Sound(Settings.SOUND_PATH + 'coin.wav')
        self.mushroomSound = mixer.Sound(Settings.SOUND_PATH + 'mushroom.wav')
        self.flowerSound = mixer.Sound(Settings.SOUND_PATH + 'flower.wav')
        self.starSound = mixer.Sound(Settings.SOUND_PATH + 'star.wav')
        '''

    def update(self, currentTime):
        if currentTime - self.gameTimer > Settings.BLOCK_REFRESH_RATE:
            if not self.gotHit:
                if self.index > 81:
                    self.index = 78
                self.image = Settings.QUESTION_IMAGES[str(self.index)]
                self.index += 1
            else:
                """
                if not self.soundPlayed:
                    if self.contains == 'coin':
                        self.coinSound.play()
                    if self.contains == 'mushroom':
                        self.coinMushroom.play()
                    if self.contains == 'flower':
                        self.flowerSound.play()
                    if self.contains == 'star':
                        self.starSound.play()   
                    self.soundPlayed = True             
                """
                if self.rect.bottom - self.startingY < Settings.BLOCK_JUMP_HEIGHT:
                    self.rect.y += Settings.BLOCK_JUMP_SPEED
                else:
                    self.rect.y -= Settings.BLOCK_JUMP_SPEED
                    if self.rect.bottom < self.startingY:
                        self.rect.bottom = self.startingY
            self.gameTimer = time.get_ticks()


    def gotHit(self, marioState):
        if not self.gotHit:
            if self.contents != 'Star' and self.contents != 'Coin':
                if marioState == 'Mini':
                    self.contents = 'Mushroom'
                if marioState == 'Normal':
                    self.contents == 'Flower'
            self.gotHit = True
            self.image = pygame.image.load(Settings.IMAGE_PATH + '75.png').convert_alpha()
