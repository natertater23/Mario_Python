

class Camera():
    def __init__(self, bgWidth):
        self.stageWidth = bgWidth
        self.stagePosX = 0
        self.startScrollingPosX = 600 #half screen width
        self.playerPosX = 20
        self.rel_x = 0



