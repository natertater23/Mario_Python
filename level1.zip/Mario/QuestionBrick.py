from pygame import *
from pygame.sprite import Sprite
import Settings

class QuestionBrick(Sprite):
    def __init__(self, xpos, ypos, ishidden = False, contains = 'Coin'):
        Sprite.__init__(self)
        self.index = 78
        self.hidden = ishidden
        if not self.hidden:
            self.image = Settings.QUESTION_IMAGES['78']
            self.image = transform.scale(self.image, (40, 40))
        self.rect = Settings.QUESTION_IMAGES['78'].get_rect(topleft=(xpos,ypos))
        self.contents = contains
        self.gotHit = False
        self.startingY = self.rect.bottom
        self.gameTimer = time.get_ticks()
        self.falling = False
        self.trigger = True
        '''  UNCOMMENT WHEN WE HAVE SOUNDS
        self.soundPlayed = False
        self.coinSound = mixer.Sound(Settings.SOUND_PATH + 'coin.wav')
        self.mushroomSound = mixer.Sound(Settings.SOUND_PATH + 'mushroom.wav')
        self.flowerSound = mixer.Sound(Settings.SOUND_PATH + 'flower.wav')
        self.starSound = mixer.Sound(Settings.SOUND_PATH + 'star.wav')
        '''

    def update(self, currentTime):
        if currentTime - self.gameTimer > Settings.BLOCK_REFRESH_RATE:
            if not self.gotHit and self.trigger:
                if self.index > 81:
                    self.index = 78
                self.image = Settings.QUESTION_IMAGES[str(self.index)]
                self.image = transform.scale(self.image, (40, 40))
                self.index += 1
                self.gameTimer = time.get_ticks()
        if currentTime - self.gameTimer > Settings.BLOCK_JUMP_FREQUENCY:
            if self.gotHit and self.trigger:
                """
                if not self.soundPlayed:
                    if self.contains == 'coin':
                        self.coinSound.play()
                    if self.contains == 'mushroom':
                        self.coinMushroom.play()
                    if self.contains == 'flower':
                        self.flowerSound.play()
                    if self.contains == 'star':
                        self.starSound.play()   
                    self.soundPlayed = True             
                """
                if self.startingY - self.rect.bottom < Settings.BLOCK_JUMP_HEIGHT and not self.falling:
                    self.rect.y -= Settings.BLOCK_JUMP_SPEED
                else:
                    self.falling = True
                    self.rect.y += Settings.BLOCK_JUMP_SPEED
                    if self.rect.bottom == self.startingY:
                        self.trigger = False
                self.gameTimer = time.get_ticks()
        Settings.SCREEN.blit(self.image, self.rect)


    def Activate(self, marioState):
        if not self.gotHit:
            if self.contents != 'Star' and self.contents != 'Coin':
                if marioState == 'Mini':
                    self.contents = 'Mushroom'
                if marioState == 'Normal':
                    self.contents == 'Flower'
            self.gotHit = True
            self.image = transform.scale(image.load(Settings.IMAGE_PATH + '4.png').convert_alpha(), (40, 40))


class GroundBrick(Sprite):
    def __init__(self, xpos, ypos):
        Sprite.__init__(self)
        self.image = image.load('Images/5.png')
        self.image = transform.scale(self.image, (40, 80))
        self.rect = self.image.get_rect(topleft=(xpos,ypos))

    def update(self):
        Settings.SCREEN.blit(self.image, self.rect)

class GroundUpBrick(Sprite):
    def __init__(self, xpos, ypos):
        Sprite.__init__(self)
        self.image = image.load('Images/6.png')
        self.image = transform.scale(self.image, (40, 40))
        self.rect = self.image.get_rect(topleft=(xpos,ypos))

    def update(self):
        Settings.SCREEN.blit(self.image, self.rect)


class NormalBrick(Sprite):
    def __init__(self, xpos, ypos):
        Sprite.__init__(self)
        #self.index = 78

        self.image = image.load('Images/0.png')
        self.image = transform.scale(self.image, (40, 40))

        self.rect = self.image.get_rect(topleft=(xpos,ypos))

        self.gotHit = False
        self.startingY = self.rect.bottom
        self.gameTimer = time.get_ticks()
        self.falling = False
        self.trigger = True
        '''  UNCOMMENT WHEN WE HAVE SOUNDS
        self.soundPlayed = False
        self.coinSound = mixer.Sound(Settings.SOUND_PATH + 'coin.wav')
        self.mushroomSound = mixer.Sound(Settings.SOUND_PATH + 'mushroom.wav')
        self.flowerSound = mixer.Sound(Settings.SOUND_PATH + 'flower.wav')
        self.starSound = mixer.Sound(Settings.SOUND_PATH + 'star.wav')
        '''

    def update(self, currentTime):
        if currentTime - self.gameTimer > Settings.BLOCK_REFRESH_RATE:
            if not self.gotHit and self.trigger:
                #if self.index > 81:
                    #self.index = 78
                #self.image = Settings.QUESTION_IMAGES[str(self.index)]
                #self.image = transform.scale(self.image, (40, 40))
                #self.index += 1
                self.gameTimer = time.get_ticks()
        if currentTime - self.gameTimer > Settings.BLOCK_JUMP_FREQUENCY:
            if self.gotHit and self.trigger:
                """
                if not self.soundPlayed:
                    if self.contains == 'coin':
                        self.coinSound.play()
                    if self.contains == 'mushroom':
                        self.coinMushroom.play()
                    if self.contains == 'flower':
                        self.flowerSound.play()
                    if self.contains == 'star':
                        self.starSound.play()   
                    self.soundPlayed = True             
                """
                if self.startingY - self.rect.bottom < Settings.BLOCK_JUMP_HEIGHT and not self.falling:
                    self.rect.y -= Settings.BLOCK_JUMP_SPEED
                else:
                    self.falling = True
                    self.rect.y += Settings.BLOCK_JUMP_SPEED
                    if self.rect.bottom == self.startingY:
                        self.trigger = False
                self.gameTimer = time.get_ticks()
        Settings.SCREEN.blit(self.image, self.rect)

class NormalPipe(Sprite):
    def __init__(self, xpos, ypos, width, height):
        Sprite.__init__(self)
        self.image = image.load('Images/7.png')
        self.image = transform.scale(self.image, (width, height))
        self.rect = self.image.get_rect(topleft=(xpos,ypos))

    def update(self):
        Settings.SCREEN.blit(self.image, self.rect)

class Flag(Sprite):
    def __init__(self, xpos, ypos):
        Sprite.__init__(self)
        self.flag_image = image.load('Images/8.png')
        self.flag_image = transform.scale(self.flag_image, (40, 40))
        self.flag_rect = self.flag_image.get_rect(topleft=(xpos,ypos))
        self.flagpole_image = image.load('Images/9.png')
        self.flagpole_image = transform.scale(self.flagpole_image, (20, 330))
        self.flagpole_rect = self.flagpole_image.get_rect(topleft=(9322,ypos))

    def update(self):
        Settings.SCREEN.blit(self.flag_image, self.flag_rect)
        Settings.SCREEN.blit(self.flagpole_image, self.flagpole_rect)

class Castle(Sprite):
    def __init__(self, xpos, ypos):
        Sprite.__init__(self)
        self.castle_image = image.load('Images/11.png')
        self.castle_image = transform.scale(self.castle_image, (220, 200))
        self.castle_rect = self.castle_image.get_rect(topleft=(xpos,ypos))
        #self.flag_image = image.load('Images/12.png')
       # self.flag_image = transform.scale(self.flag_image, (40, 40))
        #self.flag_rect = self.flag_image.get_rect(topleft=())

    def update(self):
        Settings.SCREEN.blit(self.castle_image, self.castle_rect)
        #Settings.SCREEN.blit(self.flag_image, self.flag_rect)


