from pygame import *
from pygame.sprite import Sprite
import Settings

class Mario(Sprite):
    def __init__(self, xpos, ypos, state='Mini'):
        Sprite.__init__(self)
        self.state = state
        self.fire_images = {str(index): Settings.MARIO_IMAGES[str(index)] for index in range(0, 32)}
        self.normal_images = {str(index): Settings.MARIO_IMAGES[str(index)] for index in range(32, 62)}
        self.mini_images = {str(index): Settings.MARIO_IMAGES[str(index)] for index in range(62, 88)}
        self.image = Settings.MARIO_IMAGES['{}'.format(21 if self.state == 'Fire' else 54 if self.state == 'Normal' else 75)]
        self.image = transform.scale(self.image, (20, 40))
        self.rect = self.image.get_rect(topleft=(xpos, ypos))
        self.index = 0
        self.lastGroundYPos = ypos
        self.direction = 1
        self.isCrouching = False
        self.isJumping = False
        self.isReachedApex = False
        self.isUnderwater = False
        self.isStanding = False
        self.isSliding_left = False
        self.isSliding_right = False
        self.canGoLeft = True
        self.canGoRight = True
        self.hit = False
        self.velocity_y = 0
        self.velocity_left = 0
        self.velocity_right = 0
        self.runRight = False
        self.runLeft = False
        self.idle = True
        self.timer = time.get_ticks()

    def Run(self):
        if self.runRight:
            self.direction = 1
            if self.velocity_left == 0 and not self.runLeft:
                if self.velocity_right < 5:
                    self.velocity_right += 1
                self.rect.x += Settings.MARIO_RUN_SPEED * (.85 * self.velocity_right)
            else:
                ## self.image = Settings.MARIO_IMAGES['SlideLeft']
                self.rect.x += Settings.MARIO_RUN_SPEED * (.85 * self.velocity_left)
                if self.velocity_left < 2:
                    self.velocity_left = 0
                else:
                    self.velocity_left -= 2
            self.runRight = False
        if self.runLeft:
            self.direction = -1
            if self.velocity_right == 0 and not self.runRight:
                if self.velocity_left < 5:
                    self.velocity_left += 1
                self.rect.x -= Settings.MARIO_RUN_SPEED * (.85 * self.velocity_left)
            else:
                ## self.image = Settings.MARIO_IMAGES['SlideLeft']
                self.rect.x += Settings.MARIO_RUN_SPEED * (.85 * self.velocity_right)
                if self.velocity_right < 2:
                    self.velocity_right = 0
                else:
                    self.velocity_right -= 2
            self.runLeft = False
        if self.idle:
            if self.velocity_right == 0 and self.velocity_left > 0 and self.canGoLeft:
                self.rect.x -= Settings.MARIO_RUN_SPEED * (.85 * self.velocity_right)
                self.velocity_left -= 1
            if self.velocity_right > 0 and self.velocity_left == 0 and self.canGoRight:
                self.rect.x += Settings.MARIO_RUN_SPEED * (.85 * self.velocity_right)
                self.velocity_right -= 1
            self.runRight = False
            self.runLeft = False
        self.timer = 0

    def Jump(self):
        if self.isJumping:
            if self.lastGroundYPos - self.rect.bottom < Settings.MARIO_JUMP_HEIGHT_BIG \
                    and self.isReachedApex and self.state != 'Mini':
                self.rect.y -= Settings.MARIO_JUMP_SPEED
                if self.lastGroundYPos - self.rect.bottom >= Settings.MARIO_JUMP_HEIGHT_BIG:
                    self.isReachedApex = True
            elif self.lastGroundYPos - self.rect.bottom < Settings.MARIO_JUMP_HEIGHT_MINI \
                    and not self.isReachedApex and self.state == 'Mini':
                self.rect.y -= Settings.MARIO_JUMP_SPEED
                if self.lastGroundYPos - self.rect.bottom >= Settings.MARIO_JUMP_HEIGHT_MINI:
                    self.isReachedApex = True
            else:
                self.rect.y += Settings.WORLD_FALL_SPEED

    def Fall(self):
        if not self.isJumping and not self.isUnderwater and not self.isStanding:
            self.rect.y += Settings.WORLD_FALL_SPEED

    def update(self, currentTime, doesMove = True):
        self.Jump()
        if doesMove:
            self.Run()
        self.Fall()
        Settings.SCREEN.blit(self.image, self.rect)






