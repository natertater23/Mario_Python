import Mario
import Settings
import QuestionBrick
import World
import goomba
from pygame import *
from pygame.sprite import Sprite

class SuperMario:
    def __init__(self):
        mixer.pre_init(44100, -16, 1, 4096)
        init()
        self.clock = time.Clock()
        self.screen = Settings.SCREEN
        self.should_exit = False
        self.gameTimer = time.get_ticks()

    def initGame(self):
        self.player = Mario.Mario(550, 50)
        self.world = World.World(1, 1, 1400)
        #self.goomba = goomba.Goomba(600, 50, 'normal')
        self.playerGroup = sprite.Group()
        self.groundBlocks = sprite.Group()
        self.QuestionBlocks = sprite.Group()
        self.normalBlocks = sprite.Group()
        self.normalPipes = sprite.Group()
        self.groundUpBlocks = sprite.Group()
        self.flags = sprite.Group()
        self.castles = sprite.Group()

        self.playerGroup.add(self.player)

        self.QuestionBlocks.add(QuestionBrick.QuestionBrick(771, 408))
        self.QuestionBlocks.add(QuestionBrick.QuestionBrick(1000, 408))
        self.QuestionBlocks.add(QuestionBrick.QuestionBrick(1080, 408))
        self.QuestionBlocks.add(QuestionBrick.QuestionBrick(1040, 216))
        self.QuestionBlocks.add(QuestionBrick.QuestionBrick(3736, 408))
        self.QuestionBlocks.add(QuestionBrick.QuestionBrick(3736, 408))
        self.QuestionBlocks.add(QuestionBrick.QuestionBrick(5376, 216))
        self.QuestionBlocks.add(QuestionBrick.QuestionBrick(5776, 408))
        self.QuestionBlocks.add(QuestionBrick.QuestionBrick(5856, 408))
        self.QuestionBlocks.add(QuestionBrick.QuestionBrick(5856, 216))
        self.QuestionBlocks.add(QuestionBrick.QuestionBrick(5936, 408))
        self.QuestionBlocks.add(QuestionBrick.QuestionBrick(6536, 216))
        self.QuestionBlocks.add(QuestionBrick.QuestionBrick(6576, 216))
        self.QuestionBlocks.add(QuestionBrick.QuestionBrick(7916, 408))


        self.blocks = sprite.Group()
        self.blocks.add(self.QuestionBlocks)

        self.normalBlocks.add(QuestionBrick.NormalBrick(960, 408))
        self.normalBlocks.add(QuestionBrick.NormalBrick(1040, 408))
        self.normalBlocks.add(QuestionBrick.NormalBrick(1120, 408))
        self.normalBlocks.add(QuestionBrick.NormalBrick(3696, 408))
        self.normalBlocks.add(QuestionBrick.NormalBrick(3776, 408))
        for index in range(4816, 5137, 40):
            self.normalBlocks.add(QuestionBrick.NormalBrick(index, 216))
        for index in range(5256, 5377, 40):
            self.normalBlocks.add(QuestionBrick.NormalBrick(index, 216))
        self.normalBlocks.add(QuestionBrick.NormalBrick(5376, 408))
        self.normalBlocks.add(QuestionBrick.NormalBrick(5576, 408))
        self.normalBlocks.add(QuestionBrick.NormalBrick(5616, 408))
        self.normalBlocks.add(QuestionBrick.NormalBrick(6136, 408))
        self.normalBlocks.add(QuestionBrick.NormalBrick(6216, 216))
        self.normalBlocks.add(QuestionBrick.NormalBrick(6256, 216))
        self.normalBlocks.add(QuestionBrick.NormalBrick(6296, 216))
        self.normalBlocks.add(QuestionBrick.NormalBrick(6536, 408))
        self.normalBlocks.add(QuestionBrick.NormalBrick(6576, 408))
        self.normalBlocks.add(QuestionBrick.NormalBrick(6616, 216))
        self.normalBlocks.add(QuestionBrick.NormalBrick(7836, 408))
        self.normalBlocks.add(QuestionBrick.NormalBrick(7876, 408))
        self.normalBlocks.add(QuestionBrick.NormalBrick(7956, 408))


        self.normalPipes.add(QuestionBrick.NormalPipe(1347, 507, 80, 93))
        self.normalPipes.add(QuestionBrick.NormalPipe(1824, 459, 80, 141))
        self.normalPipes.add(QuestionBrick.NormalPipe(2208, 408, 80, 192))
        self.normalPipes.add(QuestionBrick.NormalPipe(2736, 408, 80, 192))
        self.normalPipes.add(QuestionBrick.NormalPipe(7656, 507, 80, 93))
        self.normalPipes.add(QuestionBrick.NormalPipe(8592, 507, 80, 93))

        for index in range(6696, 6817, 40):
            self.groundUpBlocks.add(QuestionBrick.GroundUpBrick(index, 560))
        for index in range(6736, 6817, 40):
            self.groundUpBlocks.add(QuestionBrick.GroundUpBrick(index, 520))
        for index in range(6776, 6817, 40):
            self.groundUpBlocks.add(QuestionBrick.GroundUpBrick(index, 480))
        self.groundUpBlocks.add(QuestionBrick.GroundUpBrick(6816, 440))
        for index in range(6896, 7017, 40):
            self.groundUpBlocks.add(QuestionBrick.GroundUpBrick(index, 560))
        for index in range(6896, 6977, 40):
            self.groundUpBlocks.add(QuestionBrick.GroundUpBrick(index, 520))
        for index in range(6896, 6937, 40):
            self.groundUpBlocks.add(QuestionBrick.GroundUpBrick(index, 480))
        self.groundUpBlocks.add(QuestionBrick.GroundUpBrick(6896, 440))
        for index in range(7136, 7297, 40):
            self.groundUpBlocks.add(QuestionBrick.GroundUpBrick(index, 560))
        for index in range(7176, 7297, 40):
            self.groundUpBlocks.add(QuestionBrick.GroundUpBrick(index, 520))
        for index in range(7216, 7297, 40):
            self.groundUpBlocks.add(QuestionBrick.GroundUpBrick(index, 480))
        self.groundUpBlocks.add(QuestionBrick.GroundUpBrick(7256, 440))
        self.groundUpBlocks.add(QuestionBrick.GroundUpBrick(7296, 440))
        for index in range(7376, 7497, 40):
            self.groundUpBlocks.add(QuestionBrick.GroundUpBrick(index, 560))
        for index in range(7376, 7457, 40):
            self.groundUpBlocks.add(QuestionBrick.GroundUpBrick(index, 520))
        for index in range(7376, 7417, 40):
            self.groundUpBlocks.add(QuestionBrick.GroundUpBrick(index, 480))
        self.groundUpBlocks.add(QuestionBrick.GroundUpBrick(7375, 440))

        for index in range(8672, 8993, 40):
            self.groundUpBlocks.add(QuestionBrick.GroundUpBrick(index, 560))
        for index in range(8712, 8993, 40):
            self.groundUpBlocks.add(QuestionBrick.GroundUpBrick(index, 520))
        for index in range(8752, 8993, 40):
            self.groundUpBlocks.add(QuestionBrick.GroundUpBrick(index, 480))
        for index in range(8792, 8993, 40):
            self.groundUpBlocks.add(QuestionBrick.GroundUpBrick(index, 440))
        for index in range(8832, 8993, 40):
            self.groundUpBlocks.add(QuestionBrick.GroundUpBrick(index, 400))
        for index in range(8872, 8993, 40):
            self.groundUpBlocks.add(QuestionBrick.GroundUpBrick(index, 360))
        for index in range(8912, 8993, 40):
            self.groundUpBlocks.add(QuestionBrick.GroundUpBrick(index, 320))
        self.groundUpBlocks.add(QuestionBrick.GroundUpBrick(8952, 280))
        self.groundUpBlocks.add(QuestionBrick.GroundUpBrick(8992, 280))
        self.groundUpBlocks.add(QuestionBrick.GroundUpBrick(9312, 560))


        for index in range(0, 3363, 40):
            self.groundBlocks.add(QuestionBrick.GroundBrick(index, 600))
        for index in range(3480, 4201, 40):
            self.groundBlocks.add(QuestionBrick.GroundBrick(index, 600))
        for index in range(4377, 7298, 40):
            self.groundBlocks.add(QuestionBrick.GroundBrick(index, 600))
        self.groundBlocks.add(QuestionBrick.GroundBrick(7300, 600))
        for index in range(7375, 30519, 40):
            self.groundBlocks.add(QuestionBrick.GroundBrick(index, 600))

        self.flags.add(QuestionBrick.Flag(9292, 270))
        self.castles.add(QuestionBrick.Castle(9452,400))


    def checkInput(self, currenttime):
        if currenttime - self.gameTimer > Settings.GAME_FPS:
            self.keys = key.get_pressed()
            for e in event.get():
                if e.type == KEYDOWN:
                    if e.key == K_SPACE:
                        if not self.player.isJumping and self.player.isStanding:
                            self.player.isJumping = True
            if self.keys[K_LEFT]: #and self.player.canGoLeft:
                self.player.idle = False
                self.player.runLeft = True
                self.player.runRight = False
            elif self.keys[K_RIGHT] and not self.keys[K_LEFT]: #and self.player.canGoRight:
                self.player.idle = False
                self.player.runRight = True
                self.player.runLeft = False
            else:
                self.player.idle = True
                self.player.runLeft = False
                self.player.runLeft = False

    def check_camera(self):
        #-------move mario--------------------
        velocity = self.player.velocity_right - self.player.velocity_left
        self.world.playerPosX += velocity
        self.world.actualPosX += velocity
        if self.world.actualPosX > self.world.stageWidth:
            self.world.actualPosX = self.world.stageWidth
            self.world.playerPosX = self.world.stageWidth
        if self.world.actualPosX < 20: # half width of mario
            self.world.actualPosX = 20
            self.world.playerPosX = 20
        if self.world.playerPosX < self.world.startScrollingPosX:
            self.player.rect.right = self.world.playerPosX
        elif self.world.playerPosX > self.world.stageWidth - self.world.startScrollingPosX:
            self.player.rect.right = self.world.playerPosX - self.world.stageWidth + 1200 # screen width
        else:
            self.player.rect.right = self.world.startScrollingPosX
            if self.player.direction == 1:
                self.world.stagePosX -= velocity
            elif self.player.direction == -1:
                self.world.playerPosX = self.world.startScrollingPosX

        self.world.rel_x = self.world.stagePosX % self.world.bgWidth

        #----------move blocks
        if self.world.playerPosX >= 600:
            movement = self.player.velocity_right - self.player.velocity_left
            maxMovement = movement * ( Settings.MARIO_RUN_SPEED)
            for block in self.blocks:
                block.rect.x -= maxMovement
            for block in self.normalBlocks:
                block.rect.x -= maxMovement
            for pipe in self.normalPipes:
                pipe.rect.x -= maxMovement
            for block in self.groundUpBlocks:
                block.rect.x -= maxMovement
            for block in self.groundBlocks:
                block.rect.x -= maxMovement
            for flag in self.flags:
                flag.flag_rect.x -= maxMovement
                flag.flagpole_rect.x -= maxMovement
            for castle in self.castles:
                castle.castle_rect.x -= maxMovement

    def update(self, currentTime):
        if currentTime - self.gameTimer > Settings.GAME_FPS:
            self.screen.blit(self.world.image, (self.world.rel_x - self.world.bgWidth, 0))
            if self.world.rel_x < 1200:  # screen width
                self.screen.blit(self.world.image, (self.world.rel_x, 0))

            #self.goomba.update()
            self.player.update(currentTime)
            self.groundBlocks.update()
            self.normalPipes.update()
            self.castles.update()
            self.flags.update()
            self.normalBlocks.update(currentTime)
            self.groundUpBlocks.update()
            self.blocks.update(currentTime)
            self.gameTimer = time.get_ticks()

    def check_side(self, mario, collision):
        if mario.rect.bottom in (collision.rect.top + index for index in range(0, Settings.WORLD_FALL_SPEED + 1)):
            if mario.rect.right not in range(collision.rect.left - 5, collision.rect.left + 5):
                if mario.rect.left not in range(collision.rect.right + 5, collision.rect.left - 5):
                    if not mario.isReachedApex:
                        if mario.rect.bottom < mario.lastGroundYPos and mario.isJumping:
                            mario.isJumping = False
                        mario.lastGroundYPos = collision.rect.top + 1
                        mario.rect.bottom = collision.rect.top + 1
                        mario.isStanding = True
                    if mario.isReachedApex:
                        mario.lastGroundYPos = collision.rect.top + 1
                        mario.rect.bottom = collision.rect.top + 1
                        mario.isStanding = True
                        mario.isReachedApex = False
                        mario.isJumping = False
        if mario.rect.top in (collision.rect.bottom - index for index in range(0, 5)):
            if mario.rect.right not in range(collision.rect.left - 4, collision.rect.left + 4):
                if mario.rect.left not in range(collision.rect.right + 4, collision.rect.left - 4):
                    mario.isJumping = False
                    if collision in self.QuestionBlocks:
                        collision.Activate(mario.state)
        if mario.rect.left in (collision.rect.right + 3 - index for index in range(0, 41)):
            if mario.rect.bottom > collision.rect.top + 1:
                mario.rect.left = collision.rect.right + 2
                mario.velocity_right = 0
                mario.velocity_left = 0
                mario.runLeft = False
        if mario.rect.right in (collision.rect.left - 3 + index for index in range(0, 41)):
            if mario.rect.bottom > collision.rect.top + 1:
                mario.rect.right = collision.rect.left - 2
                mario.velocity_left = 0
                mario.velocity_right = 0
                mario.runRight = False

    def checkCollisions(self):
        self.collision = sprite.groupcollide(self.playerGroup, self.blocks, False, False)
        self.ground_collision = sprite.groupcollide(self.playerGroup, self.groundBlocks, False, False)
        self.pipe_collision = sprite.groupcollide(self.playerGroup, self.normalPipes, False, False)
        self.normalBlocks_collision = sprite.groupcollide(self.playerGroup, self.normalBlocks, False, False)
        self.groundUpBlocks_collision = sprite.groupcollide(self.playerGroup, self.groundUpBlocks, False, False)

        if self.collision:
            for mario, block in self.collision.items():
                for collision in block:
                    self.check_side(mario, collision)
        elif self.ground_collision:
            for mario, block in self.ground_collision.items():
                for collision in block:
                    self.check_side(mario, collision)
        elif self.pipe_collision:
            for mario, pipe in self.pipe_collision.items():
                for collision in pipe:
                    self.check_side(mario, collision)
        elif self.normalBlocks_collision:
            for mario, block in self.normalBlocks_collision.items():
                for collision in block:
                    self.check_side(mario, collision)
        elif self.groundUpBlocks_collision:
            for mario, block in self.groundUpBlocks_collision.items():
                for collision in block:
                    self.check_side(mario, collision)
        else:
            self.player.isStanding = False

    def mainLoop(self):
        self.initGame()
        while True:
            currentTicks = time.get_ticks()
            self.checkInput(currentTicks)
            self.check_camera()
            self.checkCollisions()
            self.update(currentTicks)
            display.update()
            self.clock.tick(30)

if __name__ == '__main__':
    game = SuperMario()
    game.mainLoop()