import random
from pygame import *
from pygame.sprite import Sprite
import Settings

# a mushroom traitor that walks back and forth
class Goomba(Sprite):
    def __init__(self, xpos, ypos, type):
        Sprite.__init__(self)
        self.type = type
        self.speed = 5
        self.direction = random.randint(0,1)
        self.is_alive = True
        if self.type == 'normal':
            self.image = image.load('Enemies/72.png') # 72, 73, 76
        else:
            self.image = image.load('Enemies/74.png') #74, 75, 71
        self.image = transform.scale(self.image, (20,20))
        self.index = 0
        self.rect = self.image.get_rect()
        #placeholders
        self.rect.x = xpos
        self.rect.y = ypos


    def update(self):
        if self.direction == 0: # left
            self.rect.x -= self.speed
        elif self.direction == 1: # right
            self.rect.x += self.speed

        Settings.SCREEN.blit(self.image, self.rect)

# a koop troopa with wings, green / red
class Koopa_Paratroopa(Sprite):
    def __init__(self, xpos, ypos, type, way):
        Sprite.__init__(self)
        self.type = type
        self.way = way # decide back and forward or up and down
        self.speed = 5
        self.direction = random.randint(0,1)
        self.is_alive = True
        if self.type == 'red':
            self.image = image.load('Enemies/85.png')  # 85, 108, 117
        else: # green
            self.image = image.load('Enemies/86.png')  # 86, 107, 118
        self.image = transform.scale(self.image, (20,30))
        self.index = 0
        self.rect = self.image.get_rect()
        #placeholders
        self.rect.x = xpos
        self.rect.y = ypos


    def update(self):
        if self.direction == 0: # down or left
            if self.way == 'ud':
                self.rect.y += self.speed
            else:
                self.rect.x -= self.speed
        elif self.direction == 1: # up or right
            if self.way == 'ud':
                self.rect.y -= self.speed
            else:
                self.rect.x += self.speed
        Settings.SCREEN.blit(self.image, self.rect)

# a turtle, green / red
class Koopa_Paratroopa(Sprite):
    def __init__(self, xpos, ypos, type):
        Sprite.__init__(self)
        self.type = type
        self.speed = 5
        self.direction = random.randint(0, 1)
        self.is_alive = True
        if self.type == 'green':
            self.image = image.load('Enemies/96.png')  # 96, 97
        else: # red
            self.image = image.load('Enemies/95.png')  # 95, 98
        self.image = transform.scale(self.image, (20, 20))
        self.index = 0
        self.rect = self.image.get_rect()
        # placeholders
        self.rect.x = xpos
        self.rect.y = ypos

    def update(self):
        if self.direction == 0:  # left
            self.rect.x -= self.speed
        elif self.direction == 1:  # right
            self.rect.x += self.speed

        Settings.SCREEN.blit(self.image, self.rect)
# a carnivorous plant
class Piranha_Plant(Sprite):
    def __init__(self, xpos, ypos, type):
        Sprite.__init__(self)
        self.type = type
        self.speed = 5
        self.direction = 0
        self.max = ypos + 20
        self.is_alive = True
        if self.type == 'green':
            self.image = image.load('Enemies/120.png')  # 120, 123
        else: # green
            self.image = image.load('Enemies/121.png')  # 121, 122
        self.image = transform.scale(self.image, (20,20))
        self.index = 0
        self.rect = self.image.get_rect()
        #placeholders
        self.rect.x = xpos
        self.rect.y = ypos


    def update(self):
        if self.direction == 0: # up
            if self.rect.y < self.max:
                self.rect.y += self.speed

                self.rect.y -= self.speed

        Settings.SCREEN.blit(self.image, self.rect)

'''
class Podoboo(Sprite):

class Cheep_cheep(Sprite):

class Fire_bar(Sprite)：

class Bloober(Sprite):
'''
