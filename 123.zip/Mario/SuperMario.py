import Mario
import Settings
import QuestionBrick
import World
from pygame import *
from pygame.sprite import Sprite

class SuperMario:
    def __init__(self):
        mixer.pre_init(44100, -16, 1, 4096)
        init()
        self.clock = time.Clock()
        self.screen = Settings.SCREEN
        self.should_exit = False
        self.gameTimer = time.get_ticks()

    def initGame(self):
        self.player = Mario.Mario(550, 50)
        self.world = World.World(1, 1, 1400)
        self.playerGroup = sprite.Group()
        self.playerGroup.add(self.player)
        self.QuestionBlocks = sprite.Group()
        self.QuestionBlocks.add(QuestionBrick.QuestionBrick(110, 160))
        for index in range(0, 3200, 16):
            self.QuestionBlocks.add(QuestionBrick.QuestionBrick(index, 216))
        self.blocks = sprite.Group()
        self.blocks.add(self.QuestionBlocks)

    def checkInput(self, currenttime):
        if currenttime - self.gameTimer > Settings.GAME_FPS:
            self.keys = key.get_pressed()
            for e in event.get():
                if e.type == KEYDOWN:
                    if e.key == K_SPACE:
                        if not self.player.isJumping and self.player.isStanding:
                            self.player.isJumping = True
            if self.keys[K_LEFT]: #and self.player.canGoLeft:
                self.player.idle = False
                self.player.runLeft = True
                self.player.runRight = False
            elif self.keys[K_RIGHT] and not self.keys[K_LEFT]: #and self.player.canGoRight:
                self.player.idle = False
                self.player.runRight = True
                self.player.runLeft = False
            else:
                self.player.idle = True
                self.player.runLeft = False
                self.player.runLeft = False

    def check_camera(self):
        #-------move mario--------------------
        velocity = self.player.velocity_right - self.player.velocity_left
        self.world.playerPosX += velocity
        if self.world.playerPosX > self.world.stageWidth:
            self.world.playerPosX = self.world.stageWidth
        if self.world.playerPosX < 10: # half width of mario
            self.world.playerPosX = 10
        if self.world.playerPosX < self.world.startScrollingPosX:
            self.player.rect.right = self.world.playerPosX
        elif self.world.playerPosX > self.world.stageWidth - self.world.startScrollingPosX:
            self.player.rect.right = self.world.playerPosX - self.world.stageWidth + 1200 # screen width
        else:
            self.player.rect.right = self.world.startScrollingPosX
            if self.player.direction == 1:
                self.world.stagePosX -= velocity
            elif self.player.direction == -1:
                self.world.playerPosX = self.world.startScrollingPosX

        #self.world.rel_x = self.world.stagePosX % self.world.bgWidth

        #----------move blocks
        if self.world.playerPosX >= 600:
            movement = self.player.velocity_right - self.player.velocity_left
            maxMovement = movement * (.85 * Settings.MARIO_RUN_SPEED)
            for block in self.blocks:
                block.rect.x -= maxMovement

    def update(self, currentTime):
        if currentTime - self.gameTimer > Settings.GAME_FPS:
            self.screen.blit(self.world.image, (0, 0))
            if self.world.rel_x < 1200:  # screen width
                self.screen.blit(self.world.image, (self.world.rel_x, 0))
            self.player.update(currentTime)
            self.blocks.update(currentTime)
            self.gameTimer = time.get_ticks()

    def check_side(self, mario, collision):
        if mario.rect.bottom in (collision.rect.top + index for index in range(0, Settings.WORLD_FALL_SPEED + 1)):
            if mario.rect.right not in range(collision.rect.left - 5, collision.rect.left + 5):
                if mario.rect.left not in range(collision.rect.right + 5, collision.rect.left - 5):
                    if not mario.isReachedApex:
                        if mario.rect.bottom < mario.lastGroundYPos and mario.isJumping:
                            mario.isJumping = False
                        mario.lastGroundYPos = collision.rect.top + 1
                        mario.rect.bottom = collision.rect.top + 1
                        mario.isStanding = True
                    if mario.isReachedApex:
                        mario.lastGroundYPos = collision.rect.top + 1
                        mario.rect.bottom = collision.rect.top + 1
                        mario.isStanding = True
                        mario.isReachedApex = False
                        mario.isJumping = False
        if mario.rect.top in (collision.rect.bottom - index for index in range(0, 5)):
            if mario.rect.right not in range(collision.rect.left - 4, collision.rect.left + 4):
                if mario.rect.left not in range(collision.rect.right + 4, collision.rect.left - 4):
                    mario.isJumping = False
                    if collision in self.QuestionBlocks:
                        collision.Activate(mario.state)
        if mario.rect.left in (collision.rect.right + 3 - index for index in range(0, 8)):
            if mario.rect.bottom > collision.rect.top + 1:
                mario.rect.left = collision.rect.right + 2
                mario.velocity_right = 0
                mario.runLeft = False
        if mario.rect.right in (collision.rect.left - 3 + index for index in range(0, 8)):
            if mario.rect.bottom > collision.rect.top + 1:
                mario.rect.right = collision.rect.left - 2
                mario.velocity_left = 0
                mario.canGoRight = False
                mario.runRight = False


    def checkCollisions(self):
        self.collision = sprite.groupcollide(self.playerGroup, self.blocks, False, False)
        if self.collision:
            for mario, block in self.collision.items():
                for collision in block:
                    self.check_side(mario, collision)
        else:
            self.player.isStanding = False

    def mainLoop(self):
        self.initGame()
        while True:
            currentTicks = time.get_ticks()
            self.checkInput(currentTicks)
            self.check_camera()
            self.checkCollisions()
            self.update(currentTicks)
            display.update()
            self.clock.tick(60)

if __name__ == '__main__':
    game = SuperMario()
    game.mainLoop()