import Mario
import Settings
import QuestionBrick
from pygame import *
from pygame.sprite import Sprite

class SuperMario:
    def __init__(self):
        mixer.pre_init(44100, -16, 1, 4096)
        init()
        self.clock = time.Clock()
        self.screen = Settings.SCREEN
        self.should_exit = False
        self.gameTimer = time.get_ticks()

    def initGame(self):
        self.player = Mario.Mario(150, 150)
        self.screen.fill((255, 255, 255))
        self.playerGroup = sprite.Group()
        self.playerGroup.add(self.player)
        self.blocks = sprite.Group()
        self.blocks.add(QuestionBrick.QuestionBrick(150, 200))

    def checkInput(self):
        self.keys = key.get_pressed()
        for e in event.get():
            if self.should_exit:
                sys.exit()
            if e.type ==KEYDOWN:
                if e.key == K_SPACE:
                    if self.player.isUnderwater:
                        if self.player.velocity_y + 2 <= 5:
                            self.player.velocity_y += 2
                        else:
                            self.player.velocity = 5
                    else:
                        if not self.player.isJumping:
                            self.player.isJumping = True
            if e.type == K_LEFT:
                if self.player.velocity_right > 0:
                        if self.player.velocity_right - 0.2 > 1:
                            self.player.velocity_right -= 0.2
                        else:
                            self.player.velocity_right = 0
                else:
                    if self.player.velocity_left + 0.2 < 2:
                        self.player.velocity_left += 0.2
                    else:
                        self.player.velocity_left = 2
            if e.type == K_RIGHT:
                if self.player.velocity_left > 1:
                    if self.player.velocity_left - 0.2 > 1:
                        self.player.velocity_left -= 0.2
                    else:
                        self.player.velocity_left = 0
                else:
                    if self.player.velocity_right + 0.2 < 2:
                        self.player.velocity_right += 0.2
                    else:
                        self.player.velocity_right = 2

    def update(self, currentTime):
        if self.player.velocity_right >= 1 and self.player.velocity_left == 0:
            if currentTime - self.gameTimer >= (Settings.GAME_FPS / self.player.velocity_right):
                self.player.rect.x += Settings.MARIO_RUN_SPEED
                self.screen.blit(self.player.image, self.player.rect)
        if self.player.velocity_left >= 1 and self.player.velocity_right == 0:
            if currentTime - self.gameTimer >= Settings.GAME_FPS / self.player.velocity_left:
                self.player.rectx += Settings.MARIO_RUN_SPEED
                self.screen.blit(self.player.image, self.player.rect)
        if currentTime - self.gameTimer > Settings.GAME_FPS:
            self.screen.fill((255, 255, 255))
            self.screen.blit(self.player.image, self.player.rect)
            self.player.update()
            for brick in self.blocks:
                brick.update(currentTime)
                self.screen.blit(brick.image, brick.rect)
            self.gameTimer = time.get_ticks()

    def checkCollisions(self):
        for mario, block in sprite.groupcollide(self.playerGroup, self.blocks, False, False):
            if mario.rect.bottom == block.rect.top:
                mario.isStanding = True

    def mainLoop(self):
        self.initGame()
        while True:
            currentTicks = time.get_ticks()
            self.checkInput()
            self.checkCollisions()
            self.update(currentTicks)
            display.update()


if __name__ == '__main__':
    game = SuperMario()
    game.mainLoop()