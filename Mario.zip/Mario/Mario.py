from pygame import *
from pygame.sprite import Sprite
import Settings

class Mario(Sprite):
    def __init__(self, xpos, ypos, state='Mini'):
        Sprite.__init__(self)
        self.state = state
        self.fire_images = {str(index): Settings.MARIO_IMAGES[str(index)] for index in range(0, 32)}
        self.normal_images = {str(index): Settings.MARIO_IMAGES[str(index)] for index in range(32, 62)}
        self.mini_images = {str(index): Settings.MARIO_IMAGES[str(index)] for index in range(62, 88)}
        self.image = Settings.MARIO_IMAGES['{}'.format(21 if self.state == 'Fire' else 54 if self.state == 'Normal' else 75)]
        self.rect = self.image.get_rect(bottomleft=(xpos, ypos))
        self.index = 0
        self.lastGroundYPos = ypos
        self.direction = 1
        self.isCrouching = False
        self.isJumping = False
        self.isUnderwater = False
        self.isStanding = False
        self.isSliding_left = False
        self.isSliding_right = False
        self.velocity_y = 0
        self.velocity_left = 0
        self.velocity_right = 0

    def update(self):
        if self.isJumping:
            if self.rect.bottom - self.lastGroundYPos < Settings.MARIO_JUMP_HEIGHT_BIG and self.state != 'Mini':
                self.rect.y -= Settings.MARIO_JUMP_SPEED
            elif self.rect.bottom - self.lastGroundYPos < Settings.MARIO_JUMP_HEIGHT_MINI and self.state == 'Mini':
                self.rect.y -= Settings.MARIO_JUMP_SPEED
            else:
                self.rect.y += Settings.WORLD_FALL_SPEED
        if not self.isJumping and not self.isUnderwater and not self.isStanding:
            self.rect.y += Settings.WORLD_FALL_SPEED




