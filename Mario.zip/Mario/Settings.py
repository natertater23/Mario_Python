from pygame import *
from pygame.sprite import Sprite
import sys
from os.path import abspath, dirname

BASE_PATH = abspath(dirname(__file__))
FONT_PATH = BASE_PATH + '/fonts/'
IMAGE_PATH = BASE_PATH + '/images/'
SOUND_PATH = BASE_PATH + '/sounds/'
MARIO_PATH = BASE_PATH + '/Mario/'
MISC_PATH = BASE_PATH + '/Misc/'

SCREEN = display.set_mode((800, 600))

MARIO_JUMP_HEIGHT_MINI = 160
MARIO_JUMP_HEIGHT_BIG = 200
MARIO_JUMP_SPEED = 10
MARIO_RUN_SPEED = 5

WORLD_FALL_SPEED = 10
BLOCK_JUMP_HEIGHT = 20
BLOCK_JUMP_SPEED = 4
GAME_FPS = 18

MARIO_IMG_NAMES = ['{}'.format(index)
                   for index in range(0, 88)]
MARIO_IMAGES = {name: image.load(MARIO_PATH + '{}.png'.format(name)).convert_alpha()
                for name in MARIO_IMG_NAMES}

QUESTION_IMG_NAMES = ['{}'.format(index)
                      for index in range(78, 82)]
QUESTION_IMAGES = {name: image.load(MISC_PATH + '{}.png'.format(name)).convert_alpha()
                   for name in QUESTION_IMG_NAMES}