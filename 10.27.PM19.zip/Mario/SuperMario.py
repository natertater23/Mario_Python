import Mario
import Settings
import QuestionBrick
from pygame import *
from numpy import arange
from pygame.sprite import Sprite

class SuperMario:
    def __init__(self):
        mixer.pre_init(44100, -16, 1, 4096)
        init()
        self.clock = time.Clock()
        self.screen = Settings.SCREEN
        self.should_exit = False
        self.gameTimer = time.get_ticks()
        self.world = 1
        self.level = 1

    def initGame(self):
        self.player = Mario.Mario(150, 190)
        self.screen.fill((255, 255, 255))
        self.playerGroup = sprite.Group()
        self.playerGroup.add(self.player)
        self.blocks = sprite.Group()
        self.blocks.add(QuestionBrick.QuestionBrick(110, 160))
        self.solid_blocks = sprite.Group()
        for index in range(0, 1600, 16):
            self.solid_blocks.add(QuestionBrick.QuestionBrick(index, 216))

    def checkInput(self, currenttime):
        if currenttime - self.gameTimer > Settings.GAME_FPS:
            self.keys = key.get_pressed()
            for e in event.get():
                if self.should_exit:
                    sys.exit()
                if e.type == KEYDOWN:
                    if e.key == K_SPACE:
                        if self.player.isUnderwater:
                            if self.player.velocity_y + 2 <= 5:
                                self.player.velocity_y += 2
                            else:
                                self.player.velocity = 5
                        else:
                            if not self.player.isJumping and self.player.isStanding:
                                self.player.isJumping = True
            if self.keys[K_LEFT]: #and self.player.canGoLeft:
                self.player.idle = False
                self.player.runLeft = True
            elif self.keys[K_RIGHT]: #and self.player.canGoRight:
                self.player.idle = False
                self.player.runRight = True
            else:
                self.player.idle = True
                self.player.runLeft = False
                self.player.runLeft = False

    def update(self, currentTime):
        if currentTime - self.gameTimer > Settings.GAME_FPS:
            self.screen.fill((255, 255, 255))
            self.screen.blit(self.player.image, self.player.rect)
            self.player.update(currentTime)
            for brick in self.blocks:
                brick.update(currentTime)
                self.screen.blit(brick.image, brick.rect)
            for brick in self.solid_blocks:
                brick.update(currentTime)
                self.screen.blit(brick.image, brick.rect)
            self.gameTimer = time.get_ticks()

    def check_side(self, mario, collision):
        if mario.rect.bottom in (collision.rect.top + index for index in range(0, 5)):
            if not mario.isReachedApex:
                mario.lastGroundYPos = collision.rect.top + 1
                mario.rect.bottom = collision.rect.top + 1
                mario.isStanding = True

            if mario.isReachedApex:
                mario.lastGroundYPos = collision.rect.top + 1
                mario.rect.bottom = collision.rect.top + 1
                mario.isStanding = True
                mario.isReachedApex = False
                mario.isJumping = False
        if mario.rect.top in (collision.rect.bottom - index for index in range(0, 5)):
            mario.isJumping = False
        if mario.rect.left in (collision.rect.right + 2 - index for index in range(0, 6)):
            if mario.rect.bottom > collision.rect.top + 1:
                mario.rect.left = collision.rect.right - 2
                mario.velocity_right = 0
                mario.canGoLeft = False
                mario.runLeft = False
        if mario.rect.right in (collision.rect.left - 2 + index for index in range(0, 6)):
            if mario.rect.bottom > collision.rect.top + 1:
                mario.rect.right = collision.rect.left + 1
                mario.velocity_left = 0
                mario.canGoRight = False
                mario.runRight = False


    def checkCollisions(self):
        self.collision = sprite.groupcollide(self.playerGroup, self.blocks, False, False)
        self.solid_collision = sprite.groupcollide(self.playerGroup, self.solid_blocks, False, False)
        if self.collision:
            for mario, block in self.collision.items():
                for collision in block:
                    self.check_side(mario, collision)

        elif self.solid_collision:
            for mario, block in self.solid_collision.items():
                for collision in block:
                    self.check_side(mario, collision)
        else:
            self.player.isStanding = False

    def mainLoop(self):
        self.initGame()
        while True:
            currentTicks = time.get_ticks()
            self.checkInput(currentTicks)
            self.checkCollisions()
            self.update(currentTicks)
            display.update()
            self.clock.tick(60)

if __name__ == '__main__':
    game = SuperMario()
    game.mainLoop()